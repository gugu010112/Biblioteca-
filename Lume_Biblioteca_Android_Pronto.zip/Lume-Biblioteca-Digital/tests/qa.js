import {Reader,parseEpub,metadata} from './readers.js';
import {zipSync,strToU8} from './vendor/fflate.mjs';
import {putBook,allBooks,deleteBook} from './storage.js';
const result=document.querySelector('#results');const log=s=>result.textContent+=s+'\n';
const host=document.querySelector('#qa-host'),area=document.querySelector('#qa-area');
const reader=new Reader(host,area,()=>{});
const assert=(ok,msg)=>{if(!ok)throw Error(msg);log('PASS · '+msg)};
const make=(format,content)=>({id:'qa-only',title:'Arquivo técnico de teste (não faz parte da biblioteca)',format,blob:new Blob([content]),position:1,highlights:[],notes:[],bookmarks:[]});
try{
 for(const [format,text] of [['txt','Texto de teste\nSegunda linha.'],['md','# Título de teste\n\n**Texto forte**'],['html','<h1>Documento HTML</h1><p>Conteúdo preservado</p><script>window.hacked=true</script>']]){
 const b=make(format,text);await reader.open(b,{theme:'sepia'});const doc=host.querySelector('iframe').contentDocument;assert(doc.body.textContent.includes(format==='txt'?'Texto de teste':format==='md'?'Texto forte':'Conteúdo preservado'),'Abertura '+format);assert(doc.querySelectorAll('script').length===0,'Conteúdo '+format+' sem scripts');if(format==='md')assert(!!doc.querySelector('strong'),'Markdown formatado');await reader.close();
 }
 const epub=new Blob([zipSync({'mimetype':strToU8('application/epub+zip'),'META-INF/container.xml':strToU8('<container><rootfiles><rootfile full-path="OEBPS/book.opf"/></rootfiles></container>'),'OEBPS/book.opf':strToU8('<package><metadata><title>EPUB técnico</title><creator>Teste</creator></metadata><manifest><item id="one" href="one.xhtml" media-type="application/xhtml+xml"/><item id="two" href="two.xhtml" media-type="application/xhtml+xml"/></manifest><spine><itemref idref="one"/><itemref idref="two"/></spine></package>'),'OEBPS/one.xhtml':strToU8('<html><body><h1>Capítulo um</h1><p>Leitura ajustável.</p></body></html>'),'OEBPS/two.xhtml':strToU8('<html><body><h1>Capítulo dois</h1><p>Fim do teste.</p></body></html>')})]);
 const e=await parseEpub(epub);assert(e.title==='EPUB técnico'&&e.chapters.length===2,'Metadados e capítulos EPUB');const b={...make('epub',''),blob:epub};await reader.open(b,{});await reader.go(2);assert(host.querySelector('iframe').contentDocument.body.textContent.includes('Capítulo dois'),'Navegação EPUB');const found=await reader.find('ajustável');assert(found===1,'Pesquisa EPUB');await reader.close();
 for(const file of ['HTML.pdf','CSharpIniciantes.pdf','JavaScript_Eloquente.pdf']){const blob=await (await fetch('books/'+file)).blob();const b={...make('pdf',''),blob};await reader.open(b,{});assert(!!host.querySelector('canvas')&&reader.total>100,'PDF real: '+file);await reader.go(2);assert(reader.page===2,'Página seguinte: '+file);if(file==='HTML.pdf'){const match=await reader.find('prefácio');assert(match>0,'Busca em PDF real')}await reader.close()}
 const stored={...make('txt','Persistência'),id:'qa-isolated-record',position:2,favorite:true,notes:[{text:'nota'}],bookmarks:[{page:2}]};await putBook(stored);const saved=(await allBooks()).find(x=>x.id===stored.id);assert(await saved.blob.text()==='Persistência'&&saved.position===2&&saved.favorite&&saved.notes[0].text==='nota','IndexedDB: arquivo, posição, favorito e anotação');await deleteBook(stored.id);assert(!(await allBooks()).some(x=>x.id===stored.id),'Remoção do registro de teste');
 log('CONCLUÍDO — todos os testes passaram.');
}catch(e){log('FALHOU: '+e.stack)}
