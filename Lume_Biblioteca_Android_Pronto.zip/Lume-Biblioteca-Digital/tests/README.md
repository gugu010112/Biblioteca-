# Testes técnicos

`qa.js` cria fixtures técnicas isoladas em memória, não livros do catálogo. Valida TXT, Markdown, HTML sanitizado, EPUB de dois capítulos, busca, abertura dos três PDFs reais, navegação e persistência IndexedDB.

Para repetir em ambiente local de desenvolvimento, copie `qa.html` e `qa.js` para `dist/`, inicie o servidor local e abra `/qa.html`. Remova as cópias de `dist/` antes de hospedar. O teste usa e remove apenas o ID `qa-isolated-record`. A prévia móvel é um iframe de 390px; não substitui teste físico Android.
