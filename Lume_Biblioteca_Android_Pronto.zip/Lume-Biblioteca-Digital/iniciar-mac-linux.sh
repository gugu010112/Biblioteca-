#!/bin/sh
cd "$(dirname "$0")" || exit 1
printf 'Abra http://localhost:8080 no navegador.\n'
python3 -m http.server 8080 --directory dist
