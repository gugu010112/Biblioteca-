@echo off
cd /d "%~dp0"
echo Abra http://localhost:8080 no navegador.
py -3 -m http.server 8080 --directory dist
pause
