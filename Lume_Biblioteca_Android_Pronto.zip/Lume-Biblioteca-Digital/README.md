# Lume — Biblioteca digital pessoal

Projeto funcional, estático e sem contas. Interface em português. Os arquivos de leitura estão incorporados; não há dependência de URLs da conversa nem de CDN.

## Começar no computador

1. Extraia o ZIP inteiro.
2. Instale Python 3, se ainda não tiver.
3. Abra um terminal na pasta extraída e execute:

```sh
python -m http.server 8080 --directory dist
```

No Linux/macOS, use `python3` se necessário. Abra **http://localhost:8080**. Mantenha o terminal aberto. Também há `iniciar-windows.bat` e `iniciar-mac-linux.sh`.

Não abra `index.html` com duplo clique: `file://` não oferece o ambiente necessário para módulos, PDF.js, workers e leitura do catálogo. No celular, use a versão hospedada ou um servidor HTTP local apropriado. O link localhost de um computador não é acessível em outro aparelho sem configurar uma conexão de rede.

Não é necessário executar npm install para usar o site: as dependências já estão em `dist/vendor/`. Node.js é necessário apenas para desenvolvimento adicional e Capacitor. Use um navegador atual com IndexedDB, módulos JavaScript, Canvas e Web Workers.

## Livros reais incluídos

| Arquivo | Identificação verificada | Páginas |
|---|---|---:|
| CSharpIniciantes.pdf | C# para iniciantes — André Carlucci, Carlos dos Santos, Claudiney Andrade, Rafael Almeida, Ray Carneiro e Renato Haddad (nomes na capa) | 267 |
| HTML.pdf | Apostila de HTML — Robertha Pereira Pedroso; PET Telecom / UFF; atualizações de Pâmella Almeida Gomes e Rafael de Oliveira Ribeiro; junho de 2007 | 101 |
| JavaScript_Eloquente.pdf | Eloquent JavaScript, 4ª edição — Marijn Haverbeke; conteúdo em inglês | 368 |

Os PDFs foram preservados byte a byte. As capas são imagens da primeira página real. Não há livros fictícios na biblioteca. Fixtures sintéticas existem somente nos testes técnicos e não são incorporadas ao catálogo.

Este pacote é destinado à sua biblioteca pessoal com os arquivos que você enviou. A inclusão não concede direitos de redistribuição pública. Eloquent JavaScript contém licença CC BY-NC 3.0 para o livro, com código sob MIT e créditos de ilustração próprios. Os outros dois PDFs mantêm seus avisos originais; não foi determinada uma licença de redistribuição. Antes de tornar uma hospedagem pública, verifique as permissões ou retire os livros de `dist/books` e use um catálogo vazio `[]`.

## Usar

- **Adicionar livros:** selecione um ou vários PDFs, EPUBs sem DRM, TXT, MD ou HTML.
- Clique na capa ou título para abrir. Use o coração para favoritos e o menu de três pontos para baixar o original, consultar o histórico ou remover.
- Busque por título/autor. Ordene por última leitura, título ou formato.
- No leitor: setas, campo de página, controle de progresso, sumário, pesquisa, zoom de PDF e tela cheia.
- O marcador guarda a posição. O caderno reúne anotações, marcadores e destaques. Para destacar, selecione texto, abra o caderno, escolha **Destaques** e **Destacar seleção**.
- Aparência oferece claro/escuro/sépia. Em EPUB/TXT/Markdown/HTML, também há fonte, espaçamento e margens.
- Atalhos fora de campos de texto: ← / → para páginas ou capítulos, F para foco e Esc para sair do foco/leitor. Nos documentos em iframe, as setas também navegam; os demais atalhos dependem do foco voltar aos controles externos.
- Preferências ficam no menu lateral ou no ícone no topo do celular. Exporte backups completos e restaure em outro navegador.

## Persistência e privacidade

Arquivos e registros são guardados em **IndexedDB**; preferências pequenas ficam em **localStorage**. Cada origem/endereço tem sua própria biblioteca. Os três livros originais são carregados na primeira execução e não reaparecem automaticamente depois de removidos. Para recuperá-los, importe novamente o PDF incluído no pacote.

Não há sincronização em nuvem. Os arquivos que você importa pelo site ficam no dispositivo; não são enviados a um servidor. Os três PDFs incorporados, por outro lado, fazem parte dos arquivos da hospedagem. A publicação inicial em Sites tem acesso privado.

Limpar dados do navegador, remover o perfil, desinstalar o aplicativo futuro ou usar sessão privada pode apagar livros e anotações. O navegador também pode remover dados por falta de espaço. Há um botão para solicitar armazenamento persistente, mas a decisão é do navegador. **Use o backup completo.** Ele contém livros, anotações e preferências, em JSON com os arquivos codificados em base64; pode ficar aproximadamente 33% maior que os arquivos originais. A restauração mescla por ID, substituindo os registros de mesmo ID.

Não use duas abas para editar simultaneamente o mesmo livro: a última gravação prevalece. A cópia completa de cada registro é gravada, incluindo referência ao Blob, para manter a implementação simples. Bibliotecas muito grandes podem exigir separar arquivos e metadados em versões futuras.

## Formatos e limites reais

| Formato | Implementação |
|---|---|
| PDF | PDF.js local; página única, total de páginas, próximo/anterior, salto, zoom, ajuste à largura, sumário quando disponível, busca por página e camada de seleção/destaques quando há texto |
| EPUB | Descompactação local, OPF, ordem do spine, capítulos, sumário EPUB 3/NCX quando presente, imagens incorporadas, texto ajustável, posição por capítulo + fração de rolagem |
| TXT | Texto UTF-8, quebras de linha preservadas, fonte e espaçamento |
| Markdown | Marked + sanitização DOMPurify, títulos, listas, tabelas e blocos de código |
| HTML | Corpo do documento sanitizado, em iframe isolado sem scripts; estilos de leitura substituem estilos originais |

Limitações:

- Sem OCR: C# tem páginas digitalizadas sem camada de texto nas páginas inspecionadas. Busca/seleção só funcionam onde há texto real. Não há busca visual em imagens.
- PDF não tem modo contínuo nesta versão. Os temas escuro/sépia usam filtro de cores e alteram a aparência de imagens. PDF com senha não tem fluxo de senha implementado.
- Busca encontra a página/capítulo que contém o termo. Não marca todas as ocorrências nem salta automaticamente para a linha exata. Buscas em PDFs extensos podem demorar.
- Destaques usam posições de texto e são vinculados à página/capítulo. Não suportam regiões desenhadas em imagens. Alterar o conteúdo original pode invalidar posições.
- EPUB é refluído; não promete fidelidade a layouts fixos, fontes próprias, CSS avançado, áudio, vídeo, scripts, MathML ou DRM. EPUB com recursos declarados como criptografados é rejeitado, inclusive alguns com fontes ofuscadas. Sumário sem nav/NCX usa os títulos dos capítulos.
- HTML preserva texto e estrutura básica. Scripts, formulários e estilos originais são removidos. Recursos externos e imagens relativas não acompanham um HTML importado sozinho; use imagens data URI ou converta o material em EPUB/PDF. Links internos funcionam; links externos do documento não são abertos pelo leitor.
- DOCX, MOBI, AZW, CBR, CBZ e outros formatos não são suportados. Converta para um formato implementado usando um programa externo. Não há conversor embutido.
- Importação limitada a 100 MB por arquivo e EPUB a 150 MB descompactados. Arquivos grandes e backups podem consumir bastante memória.
- A posição textual é proporcional à rolagem; mudar fonte ou orientação pode deslocar ligeiramente o trecho retomado.
- O Service Worker permite reabrir recursos já carregados em HTTPS/localhost. Os livros já importados continuam no IndexedDB. A disponibilidade offline completa de fontes/recursos de PDF depende de eles já terem sido carregados. Offline e instalação PWA não foram validados num dispositivo Android nesta entrega.
- Tela cheia depende do navegador. Não há APK compilado nem teste físico Android.

## Hospedar

Envie **o conteúdo da pasta `dist`**, preservando subpastas, para uma hospedagem estática HTTPS. `index.html` deve ficar na raiz publicada. Não publique `node_modules`, testes, backups pessoais ou arquivos de credenciais. Os módulos `.mjs` devem ser servidos como JavaScript; os PDFs como `application/pdf`. Não é necessário servidor de aplicação ou banco remoto.

A instalação não depende de fontes externas, CDNs ou serviços de conta. O primeiro acesso hospedado precisa baixar a interface e os livros. Para uma hospedagem pública sem redistribuir os PDFs, remova os livros e defina `catalog.json` como `[]` antes de publicar. As capas também devem ser removidas.

Ao atualizar a interface, altere a versão CACHE em `dist/sw.js` e inclua novos arquivos no SHELL. A atualização do cache não deve apagar IndexedDB. No desenvolvimento, desative o cache do Service Worker para evitar confundir uma versão antiga com a atual.

## Preparação Android / APK

Existe `capacitor.config.json` com `webDir: "dist"`, nome **Lume** e ID `br.com.lume.leitor`. A interface é responsiva e usa `<input type=file multiple>`, compatível com o seletor do Android WebView em ambientes apropriados; o fluxo ainda precisa ser validado no aparelho de destino.

Em um computador com Node.js LTS, Android Studio e SDK/JDK compatíveis com a versão instalada do Capacitor:

```sh
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
npx cap add android
npx cap sync android
npx cap open android
```

No Android Studio, aguarde a sincronização do Gradle. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)** (o nome do menu pode variar). Outra opção é, na pasta `android`:

```sh
./gradlew assembleDebug
```

No Windows: `gradlew.bat assembleDebug`. O APK de depuração normalmente será criado em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para distribuição, gere uma versão release assinada e proteja a keystore. Não publique um APK debug como versão final. Altere `appName`/`appId` antes do primeiro `cap add`; depois ajuste também o projeto Android gerado. O ícone web está em `dist/icon.svg`; para o ícone Android, use o Image Asset Studio do Android Studio ou um gerador de assets compatível, partindo desse SVG. Após alterações em `dist`, rode `npx cap sync android` novamente.

Teste no aparelho: importar um e vários arquivos, persistência depois de fechar o processo, seleção de texto por toque, botão Voltar do Android, tela cheia, acessibilidade, modo offline e PDFs grandes. A navegação usa o botão interno de voltar; integração específica com o botão físico/gesto do Android e ciclo de vida ainda não foi implementada.

Documentação oficial consultada: https://capacitorjs.com/docs/getting-started e https://capacitorjs.com/docs/android . Consulte os requisitos atuais do Android Studio/JDK para a versão de Capacitor que instalar.

## Organização e manutenção

- `dist/index.html` e `dist/style.css`: interface e layout.
- `dist/app.js`: biblioteca, ações, preferências, backups e caderno.
- `dist/readers.js`: PDF, EPUB e renderização textual sanitizada.
- `dist/storage.js`: IndexedDB e catálogo inicial.
- `dist/books/`: os três PDFs originais e capas.
- `dist/vendor/`: dependências executáveis já incluídas.
- `dist/sw.js`, `manifest.webmanifest`, `icon.svg`: cache e base instalável web.
- `capacitor.config.json`: configuração inicial Android.
- `licenses/`: licenças das bibliotecas utilizadas.
- `tests/`: testes técnicos separados da biblioteca.

Dependências fixadas no lockfile: PDF.js 4.10.38, fflate 0.8.2, Marked 15.0.12 e DOMPurify 3.2.7. Avalie atualizações e avisos de segurança antes de distribuir a terceiros. O site já usa as cópias fornecidas, não versões baixadas dinamicamente.

`npm run check` verifica a sintaxe. Consulte `TESTES.md` para o que foi efetivamente validado e o que permanece pendente.

## Gerar o APK sem instalar Android Studio no seu computador

Este ZIP inclui um workflow de GitHub Actions em `.github/workflows/android-apk.yml`. Ele pode compilar um APK debug na nuvem, mas exige uma conta GitHub e que você envie o projeto para um repositório:

1. Crie um repositório no GitHub e envie o conteúdo desta pasta.
2. Abra a aba **Actions** do repositório.
3. Escolha **Compilar APK Android** e pressione **Run workflow**.
4. Quando a execução terminar, abra a execução concluída e baixe o artefato **Lume-APK-debug** na seção **Artifacts**.
5. Extraia o arquivo e instale `app-debug.apk` no Android. O aparelho pode pedir autorização para instalar aplicativos dessa origem.

O workflow gera um APK de depuração para instalação pessoal, não uma versão assinada para publicação na Play Store. O APK ainda precisa ser testado no aparelho real; permissões de arquivos, importação e comportamento offline podem variar por versão do Android.
